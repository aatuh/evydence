Evydence sample customer package fixture.

This ZIP contains non-sensitive sample data for local package viewer and offline verification workflows.
Review manifest.json, including reviewer_checklist, before using the package as an example.
It is not legal compliance proof, certification, complete SBOM proof, an authoritative vulnerability result, or a secure-release guarantee.
