Evydence sample customer security package

This ZIP is a non-sensitive fixture for the local package viewer and offline verifier.
It contains a scoped package manifest, package metadata, and verification guidance.
It intentionally excludes raw tenant evidence payload bytes, bearer tokens, private keys, and object-store references.
